<script src="<?php echo e(asset('backend/assets/js/jquery-3.6.0.min.js')); ?>"></script>

<script src="<?php echo e(asset('backend/assets/js/feather.min.js')); ?>"></script>

<script src="<?php echo e(asset('backend/assets/js/jquery.slimscroll.min.js')); ?>"></script>

<script src="<?php echo e(asset('backend/assets/js/jquery.dataTables.min.js')); ?>"></script>

<script src="<?php echo e(asset('backend/assets/js/dataTables.bootstrap4.min.js')); ?>"></script>

<script src="<?php echo e(asset('backend/assets/js/bootstrap.bundle.min.js')); ?>"></script>



<script src="<?php echo e(asset('backend/assets/plugins/apexchart/apexcharts.min.js')); ?>"></script>


<script src="<?php echo e(asset('backend/assets/plugins/apexchart/chart-data.js')); ?>"></script>



<script src="<?php echo e(asset('backend/assets/js/script.js')); ?>"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>



<script>
    <?php if(Session::has('message')): ?>
    var type = "<?php echo e(Session::get('alert-type','info')); ?>"
    switch(type){
       case 'info':
       toastr.info(" <?php echo e(Session::get('message')); ?> ");
       break;
       case 'success':
       toastr.success(" <?php echo e(Session::get('message')); ?> ");
       break;
       case 'warning':
       toastr.warning(" <?php echo e(Session::get('message')); ?> ");
       break;
       case 'error':
       toastr.error(" <?php echo e(Session::get('message')); ?> ");
       break; 
    }
    <?php endif; ?> 
   </script>
</body>
</html>


<?php /**PATH D:\XAMPP\htdocs\inventory-management-system\resources\views/auth/auth-footer.blade.php ENDPATH**/ ?>