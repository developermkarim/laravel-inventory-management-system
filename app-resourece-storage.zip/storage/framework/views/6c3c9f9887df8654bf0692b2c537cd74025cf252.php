
<?php echo $__env->make('auth.auth-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="main-wrapper">
<div class="account-content">
<div class="login-wrapper">
   
<div class="login-content">

<div class="login-userset">
    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
<div class="login-logo">
<img src="<?php echo e(asset('backend/assets/img/logo.png')); ?>" alt="img">
</div>
<div class="login-userheading">
<h3>Sign In</h3>
<h4>Please login to your account</h4>
</div>

<div class="form-login">

<div class="form-addons">
<input type="text" id="username" name="username" placeholder="Enter your user name">
<img src="<?php echo e(asset('backend/assets/img/icons/users1.svg')); ?>" alt="img">
</div>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('username'),'class' => 'mt-2 text-danger']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('username')),'class' => 'mt-2 text-danger']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</div>

<div class="form-login">

<div class="pass-group">
<input type="password" id="password" class="pass-input" name="password" placeholder="Enter your password">
<span class="fas toggle-password fa-eye-slash"></span>
</div>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('password'),'class' => 'mt-2 text-danger']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('password')),'class' => 'mt-2 text-danger']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</div>

<div class="flex items-center justify-end mt-4">
    <?php if(Route::has('password.request')): ?>
        <a class="underline text-sm text-gray-600 hover:text-gray-900" href="<?php echo e(route('password.request')); ?>">
            <?php echo e(__('Forgot your password?')); ?>

        </a>
    <?php endif; ?>


</div>

<div class="form-login">
<button type="submit" class="btn btn-login">Sign Up</button>
</div>
<div class="signinform text-center">
<h4>Don’t have an account? <a href="<?php echo e(route('register')); ?>" class="hover-a">Sign Up</a></h4>
</div>
<div class="form-setlogin">
<h4>Or sign In with</h4>
</div>
<div class="form-sociallink">
<ul>
<li>
<a href="javascript:void(0);">
<img src="<?php echo e(asset('backend/assets/img/icons/google.png')); ?>" class="me-2" alt="google">
Sign In using Google
</a>
</li>
<li>
 <a href="javascript:void(0);">
<img src="<?php echo e(asset('backend/assets/img/icons/facebook.png')); ?>" class="me-2" alt="google">
Sign In using Facebook
</a>
</li>
</ul>
</div>
</form>

</div> 
</div>

   
<div class="login-img">
<img src="<?php echo e(asset('backend/assets/img/login.jpg')); ?>" alt="img">
</div>
</div>
</div>
</div>


<?php echo $__env->make('auth.auth-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel-inventory-management-system\resources\views/auth/login.blade.php ENDPATH**/ ?>