<img src="<?php echo e(asset('asset/logo/app.logo')); ?>" alt="">

<img width="80" height="70" src="https://www.kindpng.com/picc/m/567-5674919_inventory-management-inventory-management-system-png-transparent-png.png" alt=""><?php /**PATH D:\xampp\htdocs\laravel-inventory-management-system\resources\views/components/application-logo.blade.php ENDPATH**/ ?>