<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                <li class="<?php echo e(Request::routeis('dashboard') ? 'active':''); ?>">
                    <a href="<?php echo e(route('dashboard')); ?>">
                        <img src="<?php echo e(asset('backend/assets/img/icons/dashboard.svg')); ?>"
                            alt="img"><span>
                            Dashboard</span> </a>
                </li>
                <li class="submenu">
                    <a href="javascript:void(0);"><img src="<?php echo e(asset('backend/assets/img/icons/product.svg')); ?>" alt="img"><span>
                            Product</span> <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a class="<?php echo e(Request::routeis('product.add') ? 'active':''); ?>"  href="<?php echo e(route('product.all')); ?>">Product List</a></li>
                        <li><a  class="<?php echo e(Request::routeis('product.add') ? 'active':''); ?>"  href="<?php echo e(route('product.add')); ?>">Add Product</a></li>

                       
                    </ul>
                </li>
                <li class="submenu">
                    <a href="javascript:void(0);"><i class="fa fa-ship" data-bs-toggle="tooltip" title="" data-bs-original-title="fa fa-ship" aria-label="fa fa-ship"></i><span>
                            Manage Supplier</span> <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a class="<?php echo e(Request::routeis('supplier.all') ? 'active':''); ?>"  href="<?php echo e(route('supplier.all')); ?>">Supplier List</a></li>

                        <li><a class="<?php echo e(Request::routeis('supplier.add') ? 'active':''); ?>"  href="<?php echo e(route('supplier.add')); ?>">Add Supplier</a></li>


                       
                    </ul>
                </li>
                <li class="submenu">
                    <a href="javascript:void(0);"><img src="<?php echo e(asset('backend/assets/img/icons/users1.svg')); ?>" alt="img"><span>
                            Manage Customer</span> <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a class="<?php echo e(Request::routeis('customer.all') ? 'active':''); ?>"  href="<?php echo e(route('customer.all')); ?>">Customer List</a></li>

                        <li><a class="<?php echo e(Request::routeis('customer.add') ? 'active':''); ?>"  href="<?php echo e(route('customer.add')); ?>">Add Customer</a></li>

                        <li><a class="<?php echo e(Request::routeis('customer.paid') ? 'active':''); ?>"  href="<?php echo e(route('customer.paid')); ?>">Paid Customers</a></li>

                        <li><a class="<?php echo e(Request::routeis('customer.wise.credit.paid') ? 'active':''); ?>"  href="<?php echo e(route('customer.wise.credit.paid')); ?>">Customer Wise Report</a></li>

                        
                    </ul>
                </li>
                <li class="submenu">
                    <a href="javascript:void(0);"><i class="fa fa-balance-scale" aria-hidden="true"></i><span>
                            Manage Unit</span> <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a class="<?php echo e(Request::routeis('unit.all') ? 'active':''); ?>"  href="<?php echo e(route('unit.all')); ?>">Unit List</a></li>

                        <li><a class="<?php echo e(Request::routeis('unit.add') ? 'active':''); ?>"  href="<?php echo e(route('unit.add')); ?>">Add Supplier</a></li>
                      


                    </ul>
                </li>
                <li class="submenu">
                    <a href="javascript:void(0);"><i class=" fa fa-th-list"></i>
                        <span>
                            Manage Category</span> <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a class="<?php echo e(Request::routeis('category.all') ? 'active':''); ?>"  href="<?php echo e(url('allCategories/')); ?>">Category List</a></li>

                        <li><a class="<?php echo e(Request::routeis('category.add') ? 'active':''); ?>"  href="<?php echo e(route('category.add')); ?>">Add Category</a></li>
                      
                    </ul>
                </li>


                <li class="submenu">
                    <a href="javascript:void(0);"><img src="<?php echo e(asset('backend/assets/img/icons/purchase1.svg')); ?>" alt="img"><span>
                          Manage Purchase</span> <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a class="<?php echo e(Request::routeis('purchase.all') ? 'active':''); ?>"  href="<?php echo e(route('purchase.all')); ?>">Purchase List</a></li>
                        <li><a class="<?php echo e(Request::routeis('purchase.add') ? 'active':''); ?>"  href="<?php echo e(route('purchase.add')); ?>">Add Purchase</a></li>
                        <li><a class="<?php echo e(Request::routeis('purchase.pending') ? 'active':''); ?>"  href="<?php echo e(route('purchase.pending')); ?>">Pending Purchase</a></li>

                        <li><a class="<?php echo e(Request::routeis('purchase.daily.report') ? 'active':''); ?>"  href="<?php echo e(route('purchase.daily.report')); ?>">Purchase Daily Report</a></li>

                    </ul>
                </li>


                <li class="submenu">
                    <a href="javascript:void(0);"><img src="<?php echo e(asset('backend/assets/img/icons/sales1.svg')); ?>" alt="img"><span>
                        Manage Invoice   </span> <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a class="<?php echo e(Request::routeis('invoice.all') ? 'active':''); ?>"  href="<?php echo e(route('invoice.all')); ?>">All Invoice</a></li>

                        <li><a class="<?php echo e(Request::routeis('invoice.add') ? 'active':''); ?>"  href="<?php echo e(route('invoice.add')); ?>">Add Invoice</a></li>
                        <li><a class="<?php echo e(Request::routeis('invoice.pending_list') ? 'active':''); ?>"  href="<?php echo e(route('invoice.pending_list')); ?>">Pending Invoice</a></li>
                        <li><a class="<?php echo e(Request::routeis('invoice.print.list') ? 'active':''); ?>"  href="<?php echo e(route('invoice.print.list')); ?>">Print Invoice List</a></li>

                        <li><a class="<?php echo e(Request::routeis('invoice.daily.report') ? 'active':''); ?>"  href="<?php echo e(route('invoice.daily.report')); ?>">Print Daily Invoice</a></li>

                        
                       
                    </ul>
                </li>

                <li class="submenu">
                    <a href="javascript:void(0);"><img src="<?php echo e(asset('backend/assets/img/icons/expense1.svg')); ?>" alt="img"><span>
                            Manage Stock</span> <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a class="<?php echo e(Request::routeis('stock.report') ? 'active':''); ?>" href="<?php echo e(route('stock.report')); ?>">Stock Report</a></li>
                        <li><a class="<?php echo e(Request::routeis('stock.supplier.wise') ? 'active':''); ?>" href="<?php echo e(route('stock.supplier.wise')); ?>">Spplier/Product Wise Report</a></li>
                      
                    </ul>
                </li>
              
               
               
               
                
               
            
            
               
                
              
            </ul>
        </div>
    </div>
</div>
<?php /**PATH D:\XAMPP\htdocs\inventory-management-system\resources\views/admin/body/sidebar.blade.php ENDPATH**/ ?>