
<?php $__env->startSection('admin-content'); ?>
    
<div class="page-content print-container">
    <div class="container-fluid ">

    </div>
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="text-center">Stock Report</h4>

                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);"> </a></li>
                            <li class="breadcrumb-item active">Invoice</li>
                        </ol>
                    </div>

                </div>
            </div>
        </div>
        <!-- end page title -->

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

<div class="row">
<div class="col-12">
<div class="invoice-title">

<h3 class="text-center">
    <img src="<?php echo e(asset('backend/assets/images/logo-sm.png')); ?>" alt="logo" height="24"/> Easy Shopping Mall
</h3>
</div>
<hr>

<div class="row">
<div class="col-8 mt-4">
    <address>
        <strong>Easy Shopping Mall:</strong><br>
        Purana Palton Dhaka<br>
        support@easylearningbd.com
    </address>
</div>



</div>
</div>
</div>






<div class="row">
<div class="col-12">
<div>
<div class="p-2">
     
</div>
<div class="">
<div class="table-responsive">
<table class="table">
<thead>
<tr>
<td><strong>Sl </strong></td>
<td class="text-center"><strong>Supplier Name</strong></td>
<td class="text-center"><strong>Unit</strong></td>
<td class="text-center"><strong>Category</strong></td>
<td class="text-center"><strong>Product Name</strong>
</td>
<td class="text-center"><strong>In Quantity</strong>
</td>
<td class="text-center"><strong>Out Quantity</strong>
</td>

<td class="text-center"><strong>Stock (Current)</strong>
</td>

</tr>
</thead>
<tbody>
<!-- foreach ($order->lineItems as $line) or some such thing here -->

                       <?php $__currentLoopData = $allData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                   <?php
                       $buying_qty = App\Models\Purchase::where('category_id',$item->category_id)->where('product_id',$item->id)->where('status','1')->sum('buying_qty');
                       $selling_qty = App\Models\InvoiceDetail::where('category_id', $item->category_id)->where('product_id',$item->id)->where('status',1)->sum('selling_qty');
                   ?>    
                            <tr>
                                <td> <?php echo e($key+1); ?> </td>
                                <td> <?php echo e($item->name); ?> </td>
                                <td><?php echo e($item['supplier']['name']); ?> </td>
                                <td> <?php echo e($item['unit']['name']); ?></td>
                                <td> <?php echo e($item['category']['name']); ?> </td>
                                <td><?php echo e($buying_qty); ?></td>
                                <td><?php echo e($selling_qty); ?></td>
                                <td><?php echo e($item->quantity); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>

    <?php
        $date = new Datetime('now',new DatetimeZone('Asia/Dhaka'));
        $formattedDate =   $date->format('F j, Y, g:i a');
    ?>
    <i> <b> Printing Time : <?php echo e($formattedDate); ?></b></i>
    <div class="d-print-none">
        <div class="float-end">
            <a href="javascript:window.print()" class="btn text-white custom-btn waves-effect waves-light"><i class="fa fa-print"></i></a>
            <a href="#" class="btn btn-primary waves-effect waves-light ms-2">Download</a>
        </div>
    </div>
</div>
</div>

</div>
</div> <!-- end row -->

</div>
</div>
            </div> <!-- end col -->
        </div> <!-- end row -->

    </div> <!-- container-fluid -->
</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\inventory-management-system\resources\views/backend/pdf/stock_report_pdf.blade.php ENDPATH**/ ?>