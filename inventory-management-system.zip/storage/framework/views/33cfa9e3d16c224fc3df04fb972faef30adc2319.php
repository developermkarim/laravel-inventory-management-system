
<?php $__env->startSection('admin-content'); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

<div class="page-content">
    <div class="container">

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <h4 class="card-title">Add Supplier Page </h4><br><br>


                     <?php if(isset($editUnit)): ?>
    

                        <form id="myForm" method="post" action="<?php echo e(route('unit.update')); ?>">

                            <?php echo csrf_field(); ?>

                            <?php echo method_field('PUT'); ?>

                            <input type="hidden" name="id" value="<?php echo e($editUnit->id); ?>">
                            <div class="row mb-3">
                                <label for="example-text-input" class="col-sm-2 col-form-label">Supplier Name </label>
                                <div class="form-group col-sm-10">
                                    <input name="name" class="form-control" value="<?php echo e($editUnit->name); ?>" type="text">
                                </div>
                            </div>
                            <!-- end row -->


                          
                            <!-- end row -->


                            
                            <!-- end row -->


                           

                            
                            <!-- end row -->
                            <div class="col-lg-12">
                                <label class="col-sm-2 col-form-label"> </label>
                                <button type="submit" class="btn btn-submit me-2">Update</button>

                                <a href="<?php echo e(route('unit.all')); ?>" class="btn btn-cancel">Cancel</a>
                                </div>

                        </form>

                        <?php else: ?>
    

                        <form id="myForm" method="post" action="<?php echo e(route('unit.store')); ?>">

                            <?php echo csrf_field(); ?>

                            <div class="row mb-3">
                                <label for="example-text-input" class="col-sm-2 col-form-label">Unit Name </label>
                                <div class="form-group col-sm-10">
                                    <input name="name" class="form-control" type="text">
                                </div>
                            </div>
                            <!-- end row -->


                            
                            <!-- end row -->


                           
                            <!-- end row -->



                            
                            <!-- end row -->
                            <div class="col-lg-12">
                                <label class="col-sm-2 col-form-label"> </label>
                                <button type="submit" class="btn btn-submit me-2">Submit</button>

                                <a href="<?php echo e(route('unit.all')); ?>" class="btn btn-cancel">Cancel</a>
                                </div>

                        </form>

                        <?php endif; ?>
                    </div>
                </div>
            </div> <!-- end col -->
        </div>
    </div>
</div>


<?php $__env->startPush('customIs'); ?>

<script type="text/javascript">
    $(document).ready(function (){
        $('#myForm').validate({
            rules: {
                name: {
                    required : true,
                }, 
                 mobile_no: {
                    required : true,
                },
                 email: {
                    required : true,
                },
                 address: {
                    required : true,
                },
            },
            messages :{
                name: {
                    required : 'Please Enter Your Name',
                },
                mobile_no: {
                    required : 'Please Enter Your Mobile Number',
                },
                email: {
                    required : 'Please Enter Your Email',
                },
                address: {
                    required : 'Please Enter Your Address',
                },
            },
            errorElement : 'span', 
            errorPlacement: function (error,element) {
                error.addClass('invalid-feedback');
                element.closest('.form-group').append(error);
            },
            highlight : function(element, errorClass, validClass){
                $(element).addClass('is-invalid');
            },
            unhighlight : function(element, errorClass, validClass){
                $(element).removeClass('is-invalid');
            },
        });
    });
    
</script>

<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\inventory-management-system\resources\views/backend/unit/unit_add.blade.php ENDPATH**/ ?>