

<?php $__env->startSection('admin-content'); ?>

<div class="content">
    <div class="page-header">
        <div class="page-title">
            <h4>Product Supplier list</h4>
            <h6>View/Search product Supplier</h6>
        </div>
        <div class="page-btn">
            <a href="<?php echo e(url('unitForm')); ?>" class="btn btn-added">
               <i class="fa fa-plus"> </i> &nbsp; Add Suppliers
            </a>
        </div>
    </div>


    <!-- start page title -->
   
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    


                    <table id="datatable" class="table table-bordered dt-responsive nowrap"
                        style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                            <tr>
                                <th>Sl</th>
                                <th>Name</th>
                               <th>Status</th>
                               <th> &nbsp;</th>
                               <th> &nbsp;</th>
                                <th>Action</th>

                        </thead>


                        <tbody>

                            <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <?php echo e($key+1); ?> </td>
                                <td> <?php echo e($item->name); ?> </td>
                     

                                
                                <td>
                                    <?php if($item->status == 1): ?>
                                        <a href="<?php echo e(url('unit/status')); ?>/0/<?php echo e($item->id); ?>">
                                            <span class="badges bg-lightgreen">Activated</span>
                                        </a>
                                    <?php elseif($item->status == 0): ?>
                                    <a href="<?php echo e(url('unit/status')); ?>/1/<?php echo e($item->id); ?>"><span class="badges bg-lightred">Deactivated</span></a>
                                        
                                    <?php endif; ?>
                                </td>
                                <td></td>
                                <td></td>

                                <td>
                                    <a href="<?php echo e(route('unit.edit',$item->id)); ?>" class="btn  sm" title="Edit Data">  <img src="<?php echo e(asset('backend/assets/img/icons/edit.svg')); ?>" alt="img">
                                    </a>

                                    <a  href="<?php echo e(route('unit.delete',$item->id)); ?>" class="btn  sm" title="Delete Data" id="delete">  <img src="<?php echo e(asset('backend/assets/img/icons/delete.svg')); ?>" alt="img"> </a>

                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->

</div>

<?php $__env->startPush('customIs'); ?>
    <script>
        $(document).ready( function () {
    $('#datatable').DataTable();
} );
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\inventory-management-system\resources\views/backend/unit/unit_all.blade.php ENDPATH**/ ?>