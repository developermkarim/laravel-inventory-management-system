

<?php $__env->startSection('admin-content'); ?>
<div class="content">
    <div class="page-header">
        <div class="page-title">
            <h4>Stock list</h4>
            <h6>supplier/Product Stock</h6>
        </div>
        <div class="page-btn">
            <a href="<?php echo e(route('stock.report.pdf')); ?>" class="btn btn-added">
                <i class="fa fa-plus"> </i> &nbsp; Print Stock Report
            </a>
        </div>
    </div>


    <!-- start page title -->
    
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    


                    <table id="datatable" class="table-striped nowrap table" style="width:100%">
                        <thead>
                            <tr>
                                <th>Sl</th>
                                <th>Name</th>
                                <th>Supplier Name </th>
                                <th>Unit</th>
                                <th>Category</th>

                                <th>In Quantity</th>
                                <th>Out Quantity</th>
                                <th>Stock(current)</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $allData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $buying_qty = App\Models\Purchase::where('category_id', $item->category_id)
                            ->where('product_id', $item->id)
                            ->where(['status' => '1'])
                            ->sum('buying_qty');

                            $selling_qty = App\Models\InvoiceDetail::where('category_id', $item->category_id)
                            ->where('product_id', $item->id)
                            ->where('status', 1)
                            ->sum('selling_qty');
                            ?>
                            <tr>
                                <td> <?php echo e($key + 1); ?> </td>
                                <td> <?php echo e($item->name); ?> </td>
                                <td><?php echo e($item['supplier']['name']); ?> </td>
                                <td> <?php echo e($item['unit']['name']); ?></td>
                                <td> <?php echo e($item['category']['name']); ?> </td>
                                <td> <?php echo e($buying_qty); ?> </td>
                                <td> <?php echo e($selling_qty); ?> </td>
                                <td><?php echo e($item->quantity); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->

</div>

<?php $__env->startPush('customIs'); ?>
<script>
    $(document).ready(function () {
        $('#datatable').DataTable();
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\inventory-management-system\resources\views/backend/stock/stock_report.blade.php ENDPATH**/ ?>