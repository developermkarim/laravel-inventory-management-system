

<?php $__env->startSection('admin-content'); ?>

<div class="container mt-5">
    
    <div class="row d-flex justify-content-center">
        
        <div class="col-md-10">
            
            <div class="card p-3 py-4">
                
                <div class="text-center">
                    <img src="<?php echo e($adminModel->profile_image ? url('uploads/admin_images/'. $adminModel->profile_image) : url('uploads/default-user.png')); ?>" width="100" class="rounded-circle">
                </div>
               
               
                <div class="text-center mt-3">
                    <span class="bg-secondary p-1 px-4 rounded text-white">User Profile</span>
                    <h5 class="mt-2 mb-0"><?php echo e($adminModel->name); ?></h5>
                    <span><?php echo e($adminModel->email); ?></span>
                    
                    <div class="px-4 mt-1">
                        <p class="fonts">Consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
                    
                    </div>
                    
                     <ul class="social-list">
                        <li><i class="fa fa-facebook"></i></li>
                        <li><i class="fa fa-dribbble"></i></li>
                        <li><i class="fa fa-instagram"></i></li>
                        <li><i class="fa fa-linkedin"></i></li>
                        <li><i class="fa fa-google"></i></li>
                    </ul>
                    
                    
                        
                        
                       <a href="<?php echo e(route('admin.profile.edit',$adminModel->id)); ?>"> <button class="btn btn-submit me-2">Edit Profile</button></a>
                    
                    
                </div>
                
            </div>
            
        </div>
        
    </div>
    
</div>



 
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\inventory-management-system\resources\views/admin/admin_profile.blade.php ENDPATH**/ ?>