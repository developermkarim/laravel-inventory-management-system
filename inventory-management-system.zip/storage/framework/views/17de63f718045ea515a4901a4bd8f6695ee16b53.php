

<?php $__env->startSection('admin-content'); ?>
    <div class="content">
        <div class="page-header">
            <div class="page-title">
                <h4>Product Customer list</h4>
                <h6>View/Search product Customer</h6>
            </div>
            <div class="page-btn">
                <a href="<?php echo e(route('customer.add')); ?>" class="btn btn-added">
                    <i class="fa fa-plus"> </i> &nbsp; Add Customers
                </a>
            </div>
        </div>


        <!-- start page title -->
        
        <!-- end page title -->

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        

                        <table id="datatable" class="table table-bordered dt-responsive nowrap"
                            style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                                <tr>
                                    <th>Sl</th>
                                    <th>Name</th>
                                    <th>Profile Image</th>
                                    <th>Mobile Number </th>
                                    <th>Email</th>
                                    <th>Address</th>
                                    <th>Status</th>
                                    <th>Action</th>

                            </thead>


                            <tbody>

                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td> <?php echo e(++$key); ?> </td>
                                        <td> <?php echo e($item->name); ?> </td>
                                        <td> <img src="<?php echo e($item->customer_img_uri); ?>" alt="<?php echo e($item->name); ?>"
                                                width="60" height="60"> </td>
                                        <td> <?php echo e($item->mobile_no); ?> </td>
                                        <td> <?php echo e($item->email); ?> </td>
                                        <td> <?php echo e($item->address); ?> </td>

                                        <td>
                                            <?php if($item->status == 1): ?>
                                                <a href="<?php echo e(url('customer/status')); ?>/0/<?php echo e($item->id); ?>">
                                                    <span class="badges bg-lightgreen">unblock</span>
                                                </a>
                                            <?php elseif($item->status == 0): ?>
                                                <a href="<?php echo e(url('customer/status')); ?>/1/<?php echo e($item->id); ?>"><span
                                                        class="badges bg-lightred">block</span></a>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('customer.edit', $item->id)); ?>" class="btn text-primary sm"
                                                title="Edit Data"> <i class="fas fa-edit"></i>
                                            </a>

                                            <a href="<?php echo e(route('customer.delete', $item->id)); ?>" class="btn text-danger sm"
                                                title="Delete Data" id="delete"> <i class="fas fa-trash-alt"></i> </a>

                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>

                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->

    </div>

    <?php $__env->startPush('customIs'); ?>
        <script>
            $(document).ready(function() {
                $('#datatable').DataTable();
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\inventory-management-system\resources\views/backend/customer/customer_all.blade.php ENDPATH**/ ?>