

<?php $__env->startSection('admin-content'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

<div class="content">
    <div class="page-header">
    <div class="page-title">
    <h4>Profile</h4>
    <h6>User Profile</h6>
    </div>
    </div>
    
    <div class="card">
    <div class="card-body">
    <div class="profile-set">
    <div class="profile-head">
    </div>
    <div class="profile-top">
    <div class="profile-content">
    <div class="profile-contentimg">
    <img src="assets/img/customer/customer5.jpg" alt="img" id="blah">
    
        <img  src="<?php echo e(asset('backend/assets/img/profiles/mkarim.png')); ?>" width="100" height="100" alt="img">
    
    </div>
    </div>
    <div class="profile-contentname">
    <h2>William Castillo</h2>
    <h4>Updates Your Photo and Personal Details.</h4>
    </div>
    </div>
    <div class="ms-auto">
    <a href="javascript:void(0);" class="btn btn-submit me-2">Save</a>
    <a href="javascript:void(0);" class="btn btn-cancel">Cancel</a>
    </div>
    </div>
    </div>
    <form action="<?php echo e(route('admin.profile.update',$userData->id)); ?>" method="POST" enctype="multipart/form-data">
        $<?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
    <div class="row">
    <div class="col-lg-6 col-sm-12">
    <div class="form-group">
    <label>Full Name</label>
    <input type="text" id="name" name="name" value="<?php echo e($userData->name); ?>">
    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-danger"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    </div>
    <div class="col-lg-6 col-sm-12">
    <div class="form-group">
    <label>User Name</label>
    <input type="text" value="<?php echo e($userData->username); ?>" id="username" name="username">
    </div>
    </div>
    <div class="col-lg-6 col-sm-12">
    <div class="form-group">
    <label>Email</label>
    <input type="text" id="email" name="email" value="<?php echo e($userData->email); ?>">
    </div>
    </div>
    <div class="col-lg-6 col-sm-12">
    <div class="form-group">
    <label>Profile Image</label>
    <input type="file" id="profile" name="profile_image">
    
    </div>
    <img  id="showImage" src="<?php echo e(!empty($userData->profile_image) ? url('uploads/admin_images/'.$userData->profile_image) : url('uploads/default-user.png')); ?>" width="100" height="100" alt="img">
    </div>
   
    <div class="col-12">
    <button type="submit" class="btn btn-submit me-2">Update Profile</button>
    <a href="<?php echo e(route('admin.profile')); ?>" class="btn btn-cancel">Cancel</a>
    </div>
    </div>
</form>

    </div>
    </div>
    
    </div>

    

    <script type="text/javascript">
        
$(document).ready(function(){
 $('#profile').change(function(e){
e.preventDefault();
var reader = new FileReader();
reader.onload = function(e){
    $('#showImage').attr('src',e.target.result);
}
reader.readAsDataURL(e.target.files['0']);
            })
        })
    </script>
    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\inventory-management-system\resources\views/admin/profile_edit.blade.php ENDPATH**/ ?>